# 

This is a docker architecture. First, the docker build sends signal to docker daemon and it fetches the docker file and the docker daemon converts it to docker image and stores locally.

The docker push sends signal to docker daemon and it transfers the image locally to registry .

the docker pull sends signal to docker daemon to fetch the image in the registry . 

The docker run sends signal to docker daemon to store the image in containers .

